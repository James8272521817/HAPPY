const title = document.querySelector('.title');
// New text with spaces to become line breaks
const text = `HAPPY 
BIRTHDAY 
MAHAL`.split('');

// Clear any existing content
title.innerHTML = '';

// Prepare container styles for responsiveness
title.style.display = 'flex';
title.style.flexWrap = 'wrap';
title.style.justifyContent = 'center';
title.style.gap = '0.5rem';

for (let index = 0; index < text.length; index++) {
  if (text[index] !== ' ') {
    title.innerHTML += `<span>${text[index]}</span>`;
  } else {
    // Insert line break instead of a space
    title.innerHTML += `<br>`;
  }
}

const textElements = document.querySelectorAll('.title span');
textElements.forEach((element) => {
  const randomDelay = Math.random() * 3;
  element.style.animationDelay = `${randomDelay}s`;
});